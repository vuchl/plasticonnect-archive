﻿namespace XmlSerializing
{
	/// <summary />
	public class OrderedItem
	{
		/// <summary />
		public string ItemName { get; set; }

		/// <summary />
		public string Description { get; set; }

		/// <summary />
		public decimal UnitPrice { get; set; }

		/// <summary />
		public int Quantity { get; set; }

		/// <summary />
		public decimal LineTotal { get; set; }

		/* Calculate is a custom method that calculates the price per item,
		   and stores the value in a field. */

		/// <summary />
		public void Calculate()
		{
			LineTotal = UnitPrice * Quantity;
		}


	}
}
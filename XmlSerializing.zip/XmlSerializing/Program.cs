﻿using System;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;

namespace XmlSerializing
{
	class Program
	{
		public static void Main()
		{
			// Read and write purchase orders.
			SavePo(CreateSamplePo(), "PO.XML");

//			DisplayPo(OpenPO("PO.XML"));


/*
			Console.WriteLine(new string('-', Console.WindowWidth));
			Console.WriteLine("Press Enter to close");
			Console.ReadLine();
*/

		}

		private static void SavePo(PurchaseOrder po, string filename)
		{
			// Create an instance of the XmlSerializer class;
			// specify the type of object to serialize.
			var serializer = new XmlSerializer(typeof(PurchaseOrder));

			//Create our own namespaces for the output
			var ns = new XmlSerializerNamespaces();

			//Add an empty namespace and empty value
			ns.Add("", "");

			TextWriter writer = new StreamWriter(filename);

			var xmlTextWriter = new XmlTextWriter(writer)
			{
				Formatting = Formatting.Indented,
				Indentation = 1,
				IndentChar = '\t',
			};

			
			// Serialize the purchase order, and close the TextWriter.
			serializer.Serialize(xmlTextWriter, po, ns);
			xmlTextWriter.Close();
			writer.Close();
		}

		private static PurchaseOrder CreateSamplePo()
		{
			var po = new PurchaseOrder {OrderNumber = 34029};

			// Create an address to ship and bill to.
			var billAddress = new Address
			                  	{
			                  		Name = "Teresa Atkinson",
			                  		Line1 = "1 Main St.",
			                  		Line2 = "2 Main St.",
			                  		City = "AnyTown",
			                  		State = "WA",
			                  		Zip = "00000"
			                  	};

			// Set ShipTo and BillTo to the same addressee.
			po.ShipTo = billAddress;
			po.OrderDate = DateTime.Now.ToLongDateString();

			// Create an OrderedItem object.
			var i1 = new OrderedItem
			{
				ItemName = "Widget S",
				Description = "Small widget",
				UnitPrice = (decimal)1255.23,
				Quantity = 3
			};

			i1.Calculate();

			var i2 = new OrderedItem
			{
				ItemName = "Widget S2",
				Description = "Small widget2",
				UnitPrice = (decimal)5.24,
				Quantity = 5
			};

			i2.Calculate();

			// Insert the item into the array.
			OrderedItem[] items = { i1, i2 };
			po.OrderedItems = items;

			// Calculate the total cost.
			var subTotal = items.Sum(oi => oi.LineTotal);
			//po.SubTotal = subTotal;
			po.ShipCost = (decimal)12.51;
			po.TotalCost = po.SubTotal + po.ShipCost;

			po.NullableDecimal = 34.5m;
			
			return po;
		}

		protected static PurchaseOrder OpenPO(string filename)
		{
			// Create an instance of the XmlSerializer class;
			// specify the type of object to be deserialized.
			var serializer = new XmlSerializer(typeof(PurchaseOrder));

			/* If the XML document has been altered with unknown 
			nodes or attributes, handle them with the 
			UnknownNode and UnknownAttribute events.*/
			serializer.UnknownNode += serializer_UnknownNode;
			serializer.UnknownAttribute += serializer_UnknownAttribute;

			// A FileStream is needed to read the XML document.
			var fs = new FileStream(filename, FileMode.Open);

			// Declare an object variable of the type to be deserialized.
			/* Use the Deserialize method to restore the object's state with
			data from the XML document. */
			var po = (PurchaseOrder)serializer.Deserialize(fs);

			return po;
		}

		private static void DisplayPo(PurchaseOrder po)
		{
			Console.WriteLine("Order Number: " + po.OrderNumber);
			Console.WriteLine("Order Date: " + po.OrderDate);

			// Read the shipping address.
			Address shipTo = po.ShipTo;
			ReadAddress(shipTo, "Ship To:");
			// Read the list of ordered items.
			OrderedItem[] items = po.OrderedItems;
			Console.WriteLine("Items to be shipped:");
			foreach (OrderedItem oi in items)
			{
				Console.WriteLine("\t" +
				oi.ItemName + "\t" +
				oi.Description + "\t" +
				oi.UnitPrice + "\t" +
				oi.Quantity + "\t" +
				oi.LineTotal);
			}
			// Read the subtotal, shipping cost, and total cost.
			Console.WriteLine("\t\t\t\t\t Subtotal\t" + po.SubTotal);
			Console.WriteLine("\t\t\t\t\t Shipping\t" + po.ShipCost);
			Console.WriteLine("\t\t\t\t\t Total\t\t" + po.TotalCost);
		}

		protected static void ReadAddress(Address a, string label)
		{
			// Read the fields of the Address object.
			Console.WriteLine(label);
			Console.WriteLine("\t" + a.Name);
			Console.WriteLine("\t" + a.Line1);
			Console.WriteLine("\t" + a.City);
			Console.WriteLine("\t" + a.State);
			Console.WriteLine("\t" + a.Zip);
			Console.WriteLine();
		}

		private static void serializer_UnknownNode(object sender, XmlNodeEventArgs e)
		{
			Console.WriteLine("Unknown Node:{0}\t{1}", e.Name, e.Text);
		}

		private static void serializer_UnknownAttribute(object sender, XmlAttributeEventArgs e)
		{
			XmlAttribute attr = e.Attr;
			Console.WriteLine("Unknown attribute {0}='{1}'", attr.Name, attr.Value);
		}

	}
}

﻿using System.Xml.Serialization;

namespace XmlSerializing
{
	/// <summary />
	public class Address
	{
		/// <summary />
		/* The XmlAttribute instructs the XmlSerializer to serialize the Name
		   field as an XML attribute instead of an XML element (the default
		   behaviour). */
		[XmlAttribute]
		public string Name { get; set; }

		/// <summary />
		public string Line1 { get; set; }

		/// <summary />
		[XmlIgnore]
		public string Line2 { get; set; }

		/// <summary />
		/* Setting the IsNullable property to false instructs the 
				   XmlSerializer that the XML attribute will not appear if 
				   the City field is set to a null reference. */
		[XmlElementAttribute(IsNullable = false)]
		public string City { get; set; }

		/// <summary />
		public string State { get; set; }

		/// <summary />
		public string Zip { get; set; }
	}
}